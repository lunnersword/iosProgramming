//
//  MinigolfViewController.h
//  Minigolf
//
//  Created by Benjamin Jackson on 5/19/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MinigolfViewController : UIViewController {

}

@end
