//
//  main.m
//  AudioPlayer
//
//  Created by Neil Mix on 1/2/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
//http://du.leonards.info/COFFdD0xMzI0NTYxMDk5Jmk9MTE0LjI1MC4yMDcuMzgmdT1Tb25ncy92MS9mYWludFFDL2JkLzIyNWFiZmM4ZmI4ZTk4YTY4YmNmNjY5ZjY4MDQ0YWJkLm1wMyZtPTAxNWU2ZWRjYWVhMGE3NGNhMjAwZDI0YTA1ZWNjMjU3JnY9ZG93biZuPbzS1NqxsbyrtOUmcz2zwsn9JTIw0/S/yc6oJnA9bg==.mp3
//播放连接
int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
