//
//  main.m
//  RoutesyBART
//
//  Created by Steven Peterson on 2/14/09.
//  Copyright IMVU, Inc. 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
